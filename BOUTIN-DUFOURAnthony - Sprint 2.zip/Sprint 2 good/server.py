from flask import Flask, render_template, Response, request, send_from_directory
from classe_moteur import Moteur
from classe_robot import Robot
from classe_radionav import RadioNav, Anchor
from gpiozero import DigitalOutputDevice
from gpiozero import DigitalInputDevice
from gpiozero import PWMOutputDevice
from camera import VideoCamera
import matplotlib.pyplot as plt
from threading import Thread
import datetime

app = Flask(__name__)
pi_camera = VideoCamera(flip=False) # flip pi camera if upside down.

robot = Robot()

x = input('Veuillez entrez la position en x du anchor 1 : ')
y = input('Veuillez entrez la position en y du anchor 1 : ')
anchor1 = Anchor(x,y)

x = input('Veuillez entrez la position en x du anchor 2 : ')
y = input('Veuillez entrez la position en y du anchor 2 : ')
anchor2 = Anchor(x,y)

x = input('Veuillez entrez la position en x du anchor 3 : ')
y = input('Veuillez entrez la position en y du anchor 3 : ')
anchor3 = Anchor(x,y)

x = input('Veuillez entrez la position en x du anchor 4 : ')
y = input('Veuillez entrez la position en y du anchor 4 : ')
anchor4 = Anchor(x,y)

def gen(camera):
    #get camera frame
    while True:
        frame = camera.get_frame()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n\r\n')

#plt.plot([anchor1.pos_x, anchor2.pos_x, anchor3.pos_x, anchor4.pos_x], [anchor1.pos_y, anchor2.pos_y, anchor3.pos_y, anchor4.pos_y], 'ro')
#plt.axis([-1, 7, -1, 21])

@app.route('/')
def index():

    return render_template('index.html')
    # return render_template('cam.html')
    
@app.route('/joy')
def joy():
    return render_template('joy.html')

@app.route('/video_feed')
def video_feed():
    return Response(gen(pi_camera),
                    mimetype='multipart/x-mixed-replace; boundary=frame')



@app.route("/<deviceName>/<action>/<vitesse>")
def action(deviceName, action, vitesse):
    actionneur = ""
    v = float(vitesse) * 0.1
    
    if deviceName == 'ledYlw':
        actionneur = ledYlw
    if deviceName == 'moteur':
        actionneur = robot.moteur

    if action == "on":
        actionneur.on()
    if action == "off":
        actionneur.off()
    if action == "forward":
        robot.moteur.avancer(v)
    if action == "backward":
        robot.moteur.reculer(v)
    if action == "left":
        robot.moteur.tourner_gauche(v)
    if action == "right":
        robot.moteur.tourner_droite(v)
    if action == "stop":
        robot.moteur.reset()
    if action == "speed":
        robot.moteur.__vitesse = v
        print("speed changed to " + str(robot.moteur.__vitesse))
        
    #code exécuter à chaque action
    
    #positionnement des anchors  
        
    return render_template('index.html')


if __name__ == '__main__':
    app.run(host='0.0.0.0')
